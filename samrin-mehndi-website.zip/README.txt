# Samrin Shaikh Mehndi Website

## Files Included:
- **index.html** - Main website (Home page)
- **aboutus.html** - About Us page

## How to Upload to GitHub (Mobile):

### Step 1: Upload Files
1. Go to your GitHub repository
2. Click "Add file" → "Upload files"
3. Select BOTH files: index.html AND aboutus.html
4. Click "Commit changes"

### Step 2: Enable GitHub Pages
1. Go to Settings → Pages
2. Source: Select "main" branch
3. Click Save
4. Wait 2-5 minutes
5. Your site will be live!

### Your Website Links:
- Home: https://your-username.github.io/samrin-mehndi/
- About Us: https://your-username.github.io/samrin-mehndi/aboutus.html
